const fs=require('node:fs'),assert=require('node:assert/strict');
const {CDP,wait}=require('../mvp03-full/cdp-helper.cjs');
(async()=>{const p=await CDP.connect(9386),dir='output/architecture-fixes-20261019',errors=[];
 p.on('Runtime.exceptionThrown',e=>errors.push(e));await p.send('Runtime.enable');
 const shot=async name=>{const r=await p.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(dir+'/'+name+'.png',Buffer.from(r.data,'base64'));};
 try{
  const paused=await p.eval('!document.getElementById("status").hidden');if(paused)await p.press('Escape');
  for(const kind of ['normal','pierce','rain']){
   await p.press('KeyR');await p.key('KeyD',true);await wait(1080);await p.key('KeyD',false);
   const x=kind==='rain'?800:790,y=kind==='rain'?310:265;await p.mouse('mouseMoved',x,y);
   if(kind==='normal'){await p.mouse('mousePressed',x,y,1);await p.mouse('mouseReleased',x,y,0);}else await p.press(kind==='pierce'?'KeyQ':'KeyE');
   await wait(kind==='rain'?520:350);await shot(kind+'-live');
   await p.press('KeyR');await wait(80);await shot(kind+'-reset');
  }
  assert.equal(errors.length,0);fs.writeFileSync(dir+'/render-checks.json',JSON.stringify({surface:'packaged renderer; trusted CDP keyboard/mouse, screenshots and DOM only; no private scene access',errors,kinds:['normal','pierce','rain'],visualReview:'See live and reset screenshots'},null,2));console.log('3 live/reset screenshot pairs; zero runtime exceptions');
 }finally{await p.key('KeyD',false);await p.mouse('mouseReleased',640,360,0);p.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
