# 架构修复短流程证据 · 2026-10-19

- `verify-dom.cjs`／`dom-checks.json`：实际CDP键鼠与可见DOM检查。起点区域与下一地标、Esc暂停／恢复、暂停期间Q／E／空格／R／F不积压。
- `capture-hits.cjs`／`render-checks.json`：三轮独立普通箭／Q／箭雨操作，各拍摄运行中命中和R重试后的画面；运行异常0。
- `normal-live.png`：人工复核普通箭15；`pierce-live.png`：Q贯穿两只影偶，各40；`rain-live.png`：多目标单段各15。
- 三张`*-reset.png`：起点、满血、技能就绪，原影偶与飘字／特效清空。截图复核与规则测试分别记录。
- `01-courtyard.png`：进入第一庭院后的暂停画面，验证地图精修与分层素材正常加载。
- `manifest.json`：本轮源文件、ASAR与渲染脚本哈希；工作区基于main@8f7fe1b。

夹具源自实际macOS arm64包，只在临时HTML加入低频desktop窗口操作替代脚本。脚本不寻找源码文本，不穿入私有游戏对象，不覆盖生命、敌人、时钟或页面可见性。浏览器与临时HTTP服务在检查后关闭。

64项自动化测试覆盖规则、命中反馈生命周期、操作中断和地图语义；`npm run check`及`npm run package`通过。构建平台为macOS arm64，Chromium渲染结果不作为原生Mac／Windows体验或性能验收。未重复长时稳定性采样，未生成新的Windows发行包。

历史`output/combat-feedback-20261019/`保留上一轮实现和52项测试证据，其私有数据观察器只适用于该轮旧显示结构，不作为本轮的可重跑脚本。
