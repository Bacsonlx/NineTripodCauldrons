const fs=require('node:fs'),assert=require('node:assert/strict');
const {CDP,wait}=require('../mvp03-full/cdp-helper.cjs');
(async()=>{
 const p=await CDP.connect(9386),dir='output/architecture-fixes-20261019',errors=[],checks=[];
 p.on('Runtime.exceptionThrown',e=>errors.push(e));await p.send('Runtime.enable');
 const ui=()=>p.eval(`({region:document.getElementById('region').textContent,landmark:document.getElementById('landmark').textContent,health:document.getElementById('health').textContent,paused:!document.getElementById('status').hidden,status:document.getElementById('status').textContent,cooldowns:Object.fromEntries(['pierce','rain','dodge'].map(k=>[k,document.getElementById(k).querySelector('.seconds').textContent]))})`);
 const shot=async name=>{const s=await p.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(dir+'/'+name+'.png',Buffer.from(s.data,'base64'));};
 try{
  await p.press('KeyR');await wait(100);let s=await ui();assert.equal(s.region,'扶桑残径');assert.match(s.landmark,/扶桑石庭/);checks.push({name:'spawn-guidance',ui:s});
  await p.press('Escape');await wait(50);assert.equal((await ui()).paused,true);
  for(const key of ['KeyQ','KeyE','Space','KeyR','KeyF'])await p.press(key);
  await p.press('Escape');await wait(120);s=await ui();assert.equal(s.paused,false);assert.deepEqual(s.cooldowns,{pierce:'',rain:'',dodge:''});checks.push({name:'paused-input-not-queued',ui:s});
  await p.key('KeyD',true);await wait(1080);await p.key('KeyD',false);await p.press('Escape');await wait(50);await shot('01-courtyard');
  fs.writeFileSync(dir+'/dom-checks.json',JSON.stringify({surface:'packaged renderer in Chromium, visible DOM and trusted input only',checks,errors},null,2));
  console.log(await ui());
 }finally{await p.key('KeyD',false);p.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
